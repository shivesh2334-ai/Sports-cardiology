# Sports Cardiology Risk Navigator
Next.js app built from the 2020 ESC Guidelines on sports cardiology and exercise in patients with CVD.
Select a condition, enter findings, get a risk tier, class/level-graded recommendations with evidence, and suggested tests with rationale.

    npm install && npm run dev

Deploy: push to GitHub, import the repo in Vercel (framework auto-detected as Next.js).
